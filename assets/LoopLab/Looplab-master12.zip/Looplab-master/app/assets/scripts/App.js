// jquery is used for bootstrap
import $ from "jquery";
import 'bootstrap';
import Copyright from "./modules/copyright";
import Scrollspy from "./modules/scrollspy";

let copyright = new Copyright();
let scrollpy = new Scrollspy();
