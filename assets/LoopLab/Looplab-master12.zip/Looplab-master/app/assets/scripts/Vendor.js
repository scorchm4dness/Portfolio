
import "../../temp/scripts/modernizr";
import 'picturefill';
import 'lazysizes';
import "popper.js";
import "../../../node_modules/@fortawesome/fontawesome-free/js/all.js";
